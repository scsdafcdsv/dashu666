import { Command } from "commander"
import type { OpenSeaClient } from "../client.js"
import type { OutputFormat } from "../output.js"
import { formatOutput, outputGet } from "../output.js"
import { parseFloatOption } from "../parse.js"
import { resolveQuantity, SwapsAPI } from "../sdk.js"
import type { WalletProvider } from "../wallet/index.js"
import {
  createWalletForProvider,
  createWalletFromEnv,
  isEvmAdapter,
  WALLET_PROVIDERS,
  WrongChainTypeError,
} from "../wallet/index.js"

export function swapsCommand(
  getClient: () => OpenSeaClient,
  getFormat: () => OutputFormat,
): Command {
  const cmd = new Command("swaps").description(
    "Get swap quotes and execute token swaps",
  )

  cmd
    .command("quote")
    .description(
      "Get a quote for swapping tokens, including price details and executable transaction data",
    )
    .requiredOption("--from-chain <chain>", "Chain of the token to swap from")
    .requiredOption(
      "--from-address <address>",
      "Contract address of the token to swap from",
    )
    .requiredOption("--to-chain <chain>", "Chain of the token to swap to")
    .requiredOption(
      "--to-address <address>",
      "Contract address of the token to swap to",
    )
    .requiredOption(
      "--quantity <quantity>",
      "Amount to swap (decimals like 0.1 are auto-converted to smallest units)",
    )
    .requiredOption("--address <address>", "Wallet address executing the swap")
    .option(
      "--slippage <slippage>",
      "Slippage tolerance (0.0 to 0.5, default: 0.01)",
    )
    .option(
      "--recipient <recipient>",
      "Recipient address (defaults to sender address)",
    )
    .action(
      async (options: {
        fromChain: string
        fromAddress: string
        toChain: string
        toAddress: string
        quantity: string
        address: string
        slippage?: string
        recipient?: string
      }) => {
        const client = getClient()
        const quantity = await resolveQuantity(
          client,
          options.fromChain,
          options.fromAddress,
          options.quantity,
        )
        await outputGet(client, getFormat(), "/api/v2/swap/quote", {
          from_chain: options.fromChain,
          from_address: options.fromAddress,
          to_chain: options.toChain,
          to_address: options.toAddress,
          quantity,
          address: options.address,
          slippage: options.slippage
            ? parseFloatOption(options.slippage, "--slippage")
            : undefined,
          recipient: options.recipient,
        })
      },
    )

  cmd
    .command("execute")
    .description(
      "Get a swap quote and execute it onchain using a managed wallet. " +
        "Supports Privy (default), Turnkey, Fireblocks, and Bankr providers.",
    )
    .requiredOption("--from-chain <chain>", "Chain of the token to swap from")
    .requiredOption(
      "--from-address <address>",
      "Contract address of the token to swap from",
    )
    .requiredOption("--to-chain <chain>", "Chain of the token to swap to")
    .requiredOption(
      "--to-address <address>",
      "Contract address of the token to swap to",
    )
    .requiredOption(
      "--quantity <quantity>",
      "Amount to swap (decimals like 0.1 are auto-converted to smallest units)",
    )
    .option(
      "--slippage <slippage>",
      "Slippage tolerance (0.0 to 0.5, default: 0.01)",
    )
    .option(
      "--recipient <recipient>",
      "Recipient address (defaults to wallet address)",
    )
    .option(
      "--wallet-provider <provider>",
      `Wallet provider to use (${WALLET_PROVIDERS.join(", ")})`,
    )
    .option("--dry-run", "Print quote and transaction details without signing")
    .action(
      async (options: {
        fromChain: string
        fromAddress: string
        toChain: string
        toAddress: string
        quantity: string
        slippage?: string
        recipient?: string
        walletProvider?: string
        dryRun?: boolean
      }) => {
        const wallet = options.walletProvider
          ? createWalletForProvider(options.walletProvider as WalletProvider)
          : createWalletFromEnv()
        // Swap execution builds EVM transactions, so a Solana wallet cannot run it yet. The
        // factory returns whatever is configured, so this is where the mismatch surfaces.
        if (!isEvmAdapter(wallet)) {
          console.error(
            `Error: ${new WrongChainTypeError(wallet, "evm", "swap execution").message}`,
          )
          process.exit(1)
        }
        const address = await wallet.getAddress()
        console.error(`Using ${wallet.name} wallet: ${address}`)

        const client = getClient()
        const quantity = await resolveQuantity(
          client,
          options.fromChain,
          options.fromAddress,
          options.quantity,
        )
        const swaps = new SwapsAPI(client)
        const format = getFormat()
        const slippage = options.slippage
          ? parseFloatOption(options.slippage, "--slippage")
          : undefined

        if (options.dryRun) {
          const quote = await swaps.quote({
            ...options,
            quantity,
            address,
            slippage,
          })
          console.log(formatOutput(quote, format))
          return
        }

        const results = await swaps.execute(
          {
            ...options,
            quantity,
            address,
            slippage,
          },
          wallet,
          {
            onQuote: () =>
              console.error(
                `Quote: ${options.quantity} on ${options.fromChain} → ${options.toChain}`,
              ),
            onSending: tx =>
              console.error(
                `Sending transaction to ${tx.to} on chain ${tx.chain} (${tx.chainId})...`,
              ),
            onSkipped: tx =>
              console.error(
                `Skipping transaction on ${tx.chain}: ${tx.reason}`,
              ),
          },
        )

        for (const result of results) {
          console.log(formatOutput({ hash: result.hash }, format))
        }
      },
    )

  return cmd
}
